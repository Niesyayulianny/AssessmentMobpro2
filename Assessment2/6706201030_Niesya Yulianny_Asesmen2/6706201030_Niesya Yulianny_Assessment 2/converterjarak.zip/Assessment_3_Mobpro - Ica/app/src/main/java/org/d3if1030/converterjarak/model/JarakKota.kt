package org.d3if1030.converterjarak.model

data class JarakKota(
    val nama: String,
    val jarak: String,
    val image: String
)