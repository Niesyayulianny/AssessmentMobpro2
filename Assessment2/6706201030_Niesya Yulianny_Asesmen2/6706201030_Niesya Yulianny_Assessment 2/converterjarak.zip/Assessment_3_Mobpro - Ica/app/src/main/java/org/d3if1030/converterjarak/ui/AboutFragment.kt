package org.d3if1030.converterjarak.ui

import androidx.fragment.app.Fragment
import org.d3if1030.converterjarak.R

class AboutFragment : Fragment(R.layout.fragment_about)