package org.d3if1030.converterjarak.model

data class Hasil(
    val hasil: Float
)